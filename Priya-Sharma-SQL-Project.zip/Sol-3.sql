-- Write a query to print the transaction details (all columns from the table) for each card type when it reaches a cumulative of 1000000 total spends
with cte1 as (
select *, sum(Amount) over (partition by `Card Type` order by Date) as cum_sum
from codebasics.`credit card transactions`
),
cte2 as (
select *, row_number() over (partition by `Card Type` order by Date) as ra_nk
from cte1
where cum_sum>=1000000
)
select * from cte2
where ra_nk=1
