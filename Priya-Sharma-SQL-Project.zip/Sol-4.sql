-- Write a query to find city which had lowest percentage spend for gold card type.
with cte1 as (select City, sum(Amount) as gold_spent
from codebasics.`credit card transactions`
where `Card Type`='Gold'
group by City),
cte2 as (
select City, sum(Amount) as Total_spent from codebasics.`credit card transactions`
group by City
)
select cte1.City, (cte1.gold_spent/cte2.Total_spent)*100 as percentage from cte1
join cte2 on cte2.City=cte1.City
order by percentage asc
