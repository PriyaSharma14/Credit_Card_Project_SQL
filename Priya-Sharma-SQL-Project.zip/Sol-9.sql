-- Which city took least number of days to reach its 500th transaction after first transaction in that city?
with cte1 as (
    select city, date, row_number() over (partition by city order by date) as rnk
    from codebasics.`credit card transactions`
),
cte2 as (
    select city, min(case when rnk = 1 then date end) as first_date, min(case when rnk = 500 then date end) as dateof500th
    from cte1
    group by city
    having count(*) >= 500
)
select city, datediff(dateof500th, first_date) as daystoreach500
from cte2
order by daystoreach500 asc
limit 1
