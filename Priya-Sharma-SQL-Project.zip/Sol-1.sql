#Write a query to print top 5 cities with highest spends and their percentage contribution of total credit card spends


with my_table as (
select city, sum(Amount) as `total` from codebasics.`credit card transactions`
group by city
order by 'total spends' desc 
limit 5
),
total_credit_spend as (
SELECT SUM(Amount) AS Total_Spend
FROM codebasics.`credit card transactions`
)
select m.city, m.total , round((m.total/t.Total_Spend)*100,2) as Percentage_Contribution
from my_table as m , total_credit_spend as t;