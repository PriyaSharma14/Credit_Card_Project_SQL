-- Write a query to print 3 columns: city, highest_expense_type , lowest_expense_type (example format : Delhi , bills, Fuel).
with expense_summary as (
    select city, `Exp Type`, sum(Amount) as total_spent,
        row_number() over (partition by City order by sum(Amount) desc) as rn_highest,
        row_number() over (partition by City order by sum(Amount) asc) as rn_lowest
    from `credit card transactions`
    group by City, `Exp Type`
)
select city, max(case when rn_highest = 1 then `Exp Type` end) as highest_expense_type, max(case when rn_lowest = 1 then `Exp Type` end) as lowest_expense_type
from  expense_summary
group by City;
