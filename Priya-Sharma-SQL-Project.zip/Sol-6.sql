-- Write a query to find percentage contribution of spends by females for each expense type.
WITH female AS 
(
    SELECT Gender, `Exp Type`, SUM(Amount) AS Amount 
    FROM `credit card transactions`
    WHERE Gender = 'F'
    GROUP BY `Exp Type`
),
total AS 
(
    SELECT `Exp Type`, SUM(Amount) AS Amount 
    FROM `credit card transactions`
    GROUP BY `Exp Type`
)
SELECT 
    female.`Exp Type`, 
    (female.Amount / total.Amount) * 100 AS Percentage_contri
FROM 
    female 
JOIN 
    total 
ON 
    female.`Exp Type` = total.`Exp Type`;
