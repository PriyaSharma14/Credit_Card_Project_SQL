-- Which card and expense type combination saw highest month over month growth in Jan-2014(Means from Dec-2013 to Jan-2014).
with cte1 as 
(select `Card Type`, `Exp Type`, Date_format(date, "%Y-%m") as month_year, sum(Amount) as t_amount from `credit card transactions`
where Date_format(date, "%Y-%m")='2013-12'
group by `Card Type`, `Exp Type`, month_year
),
cte2 as (
select `Card Type`, `Exp Type`, Date_format(date, "%Y-%m") as month_year, sum(Amount) as t_amount from `credit card transactions`
where Date_format(date, "%Y-%m")='2014-01'
group by `Card Type`, `Exp Type`, month_year
)
select cte1.`Card Type`, cte1.`Exp Type`, ((cte2.t_amount-cte1.t_amount)/ cte1.t_amount)*100 as growth_percentage
from cte1
join cte2 on cte1.`Card Type`=cte2.`Card Type` and cte1.`Exp Type`=cte2.`Exp Type`
order by growth_percentage desc
