-- During weekends which city has highest total spend to total no of transaction’s ratio?
select City, sum(Amount)/count(Amount) as ratio from `credit card transactions`
where dayofweek(Date) in (1,7)
group by City
order by sum(Amount)/count(Amount) desc
limit 1
