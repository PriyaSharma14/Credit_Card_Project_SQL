#Write a query to print highest spend month and amount spent in that month for each card type.
#highest spend month and amount spent
#( basically hmlog ko isme date mn se month extract kro and then month pr group by lagao , and all 4 tyope k card type ka amount spend nikalo

-- Define the CTE to find the month with the highest total transaction amount
WITH my_table1 AS (
    SELECT 
        DATE_FORMAT(STR_TO_DATE(Date, '%d-%b-%y'), '%b') AS Month, 
        SUM(Amount) AS Total_Amount 
    FROM 
        codebasics.`credit card transactions`
    GROUP BY 
        Month
    ORDER BY 
        Total_Amount DESC
    LIMIT 1
)

-- Main query to select the required columns
SELECT 
    mt1.Month,
    ct.`Card Type`,
    SUM(ct.Amount) AS Total_Per_Card_Type
FROM 
    codebasics.`credit card transactions` ct
JOIN 
    my_table1 mt1
ON 
    DATE_FORMAT(STR_TO_DATE(ct.Date, '%d-%b-%y'), '%b') = mt1.Month
GROUP BY 
    mt1.Month, ct.`Card Type`
ORDER BY 
    Total_Per_Card_Type ASC;
   